// POE login and registration 
package poe2024.chrisma;

import java.util.HashMap;
import java.util.Scanner;

public class Login {
    public void performLogin(HashMap<String, String> users) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Login");
        System.out.print("Username:");
        String username = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        // function used to check if this username already exists 
        if (!users.containsKey(username)) {
            System.out.println("the username provided is incorrect");
            return;
        }

        // function used to verify if the password is correct 
        if (!users.get(username).equals(password)) {
            System.out.println("The password provided is incorrect ");
            return;
        }

        System.out.println("Login successful, welcome to the kanban app");
    }
}

// ProgrammingPOEChrismaDibwe.java
public class ProgrammingPOEChrismaDibwe {
    private static HashMap<String, String> users = new HashMap<>();

    // Registration
    public static void register() {
        //Variables
        String username;
        String password;

        Scanner sc = new Scanner(System.in);

        System.out.println("Username >>");
        username = sc.nextLine();

        
        
        
        // Checking if username meets format requirements 
        if (!iscorrectUsername(username)) {
            System.out.println("Username is not correctly formatted please ensure that your username contains an underscore and is no more than 5 characters ");
            return;
        } else {
            System.out.println("username successfully captured");
        }

        System.out.println("Password >>");
        password = sc.nextLine();

        // checking if the password inputted meets format requirements 
        if (!iscorrectPassword(password)) {
            System.out.println("Password must be at least 8 characters long and contain at least one number, one uppercase letter, and one special character.");
            return;
        } else {
            System.out.println("password successfully loaded");
        }

        // Checking if the username inputted already exists 
        if (users.containsKey(username)) {
            System.out.println("Username already exists. Please choose a different username.");
            return;
        }

        // Store user data
        users.put(username, password);
        System.out.println("Registration successful! You can now login.");
    }

    // Function to validate username format
    public static boolean iscorrectUsername(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // Function to validate password format
    public static boolean iscorrectPassword(String password) {
        return password.length() >= 8 && password.matches(".*\\d.*") && password.matches(".*[A-Z].*") && password.matches(".*[^a-zA-Z0-9].*");
    }

    public static void main(String[] args) {
        // Registration
        register();

        // Login
        Login login = new Login();
        login.performLogin(users);
    }
}
